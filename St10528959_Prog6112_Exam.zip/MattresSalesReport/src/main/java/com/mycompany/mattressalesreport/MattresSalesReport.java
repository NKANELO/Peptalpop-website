

package com.mycompany.mattressalesreport;


public class MattresSalesReport {

    public static void main(String[] args) {
        
              String MattressName [] = {"Cozy Nights Mononarch" , "Restonic Barbados" , "Sealy Phuket "};
        //1D array to store Sales made
        String Salesmonth [] ={"month 1","month 2" ,"month 3"};
        // 2-DIMENSIONAL ARRAY: Stores sales data
        // Row 0 = YEAR 1, Row 1 = YEAR 2
        // Col 0 = QUARTER 1, Col 1 = QUARTER 2, Col 2 = QUARTER 3
        double[][] Amount_of_sales = {{25,10, 20},
                {15 , 10 , 12},
                {18 ,15 , 20}
         
        };

        // SINGLE-DIMENSIONAL ARRAY: Labels for display (optional, for neat output)
     
        // Variables to hold our calculations
        // We start total at 0, then add each sale to it
        int total = 0;

        // We start max and min with the very first value in the array
        // so we have something to compare against
        double maximum = Amount_of_sales[0][0];
        double minimum = Amount_of_sales[0][0];

        // Counter to count how many sales values we have
        // 2 years x 3 quarters = 6 values
        int count = 0;

        // OUTER LOOP: Loops through the years (rows)
        for (int i = 0; i < Amount_of_sales.length; i++) {
            // INNER LOOP: Loops through the quarters (columns) for that year
            for (int j = 0; j < Amount_of_sales[i].length; j++) {

                // Add current sale to total
                total += Amount_of_sales[i][j];

                // Check if current sale is bigger than current maximum
                // If yes, it becomes the new maximum
                if (Amount_of_sales[i][j] > maximum) {
                    maximum = Amount_of_sales[i][j];
                }

             

                // Increase count by 1 for each value processed
                count++;
            }
        }

    
        double averageExact = (double) total / count;
        long average = Math.round(averageExact);

        // DISPLAY THE REPORT - Must match the format in the question
        System.out.println("Entter number of sales for month 1 for Cozy Nights Monarch mattress: 25");
        System.out.println("Entter number of sales for month 2 for Cozy Nights Monarch mattress: 10");
        System.out.println("Entter number of sales for month 3 for Cozy Nights Monarch mattress: 20");
        
        System.out.println("Entter number of sales for month 1 for Restonic mattress:15 ");
        System.out.println("Entter number of sales for month 2 for Restonic mattress:10 ");
         System.out.println("Entter number of sales for month 3 for Restonic mattress:12 ");
         
          System.out.println("Entter number of sales for month 1 for Sealy Phuket Mattress:18 ");
                    System.out.println("Entter number of sales for month 2 for Sealy Phuket Mattress:15 ");
                              System.out.println("Entter number of sales for month 3 for Sealy Phuket Mattress:20 ");
        
        System.out.println("=================================");
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("---------------------------------");
        System.out.println("Total sales:    " + total);
        System.out.println("Average sales:  " + average);
        System.out.println("Maximum sale:   " + maximum);
        
        System.out.println("=================================");
    
    }
           }

