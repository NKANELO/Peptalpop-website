
package com.mycompany.mattressalesgui;


public interface IProductCalculations {
    
    double GetVat(double[][] productSales);
    double GetCommission(double[][] productSales);
    double GetTotal(double[][] productSales);
}
