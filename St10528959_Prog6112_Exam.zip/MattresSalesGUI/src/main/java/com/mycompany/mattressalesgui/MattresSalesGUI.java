
package com.mycompany.mattressalesgui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class MattresSalesGUI extends JFrame {

    Scanner scan = new Scanner(System.in);
    
    private String name;
    
  private JButton btnSave; 
 private JButton btnLoad;
 

  
    private JTextArea txtResults;

    
    private JLabel lblYears;

        private String[] ProductName = { "Cozy Nights Mononarch" , "Restonic Barbados" , "Sealy Phuket "
         
    };
    
    // Sales limit from the question - set at 500
    // If sale > 500 = over limit, if sale <= 500 = under limit
    private final int SALES_LIMIT = 500;

    // This will hold the ProductSales object to do calculations
    private MatrtresProduct salesCalc = new MatrtresProduct();

    // 3. CONSTRUCTOR - This runs when the window is created
    // It builds all the buttons and puts them on the screen
    public MattresSalesGUI() {
        // Set window title - must match screenshot: "Product Sales Application"
        setTitle("Mattres Sales Application");
        setSize(380, 320); // Width, Height
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close app when X is clicked
        setLocationRelativeTo(null); // Centre window on screen
        setLayout(new BorderLayout()); // Layout: Top, Centre, Bottom

        // --- MENU BAR: File, Edit (to match screenshot) ---
        JMenuBar menuBar = new JMenuBar();
        JMenu menuFile = new JMenu("File");
        JMenu menuEdit = new JMenu("Edit");
        menuBar.add(menuFile);
        menuBar.add(menuEdit);
        setJMenuBar(menuBar);

        // --- TOP PANEL: Holds the 2 buttons ---
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(2, 1, 5, 5)); // 2 rows, 1 column, gaps

        // Create Load button
        btnLoad = new JButton("Enter you Name");
        String CustormerName = scan.nextLine();
        
      
        btnLoad = new JButton("Select Product");
                String ProductName = scan.nextLine();
        
        btnLoad = new JButton("Enter Price");
         double price = scan.nextDouble();
        // Create Save button
        btnSave = new JButton("Process");
         

        // Add buttons to top panel
        topPanel.add(btnLoad);
        topPanel.add(btnSave);

        // --- CENTRE: Text area for results ---
        txtResults = new JTextArea();
        txtResults.setEditable(false); // User cannot type in it, only we can
        txtResults.setFont(new Font("Arial", Font.PLAIN, 14));
        // Add scrollbars if text gets long
        JScrollPane scroll = new JScrollPane(txtResults);

        // --- BOTTOM: Label for Years Processed ---
        lblYears = new JLabel("Years Processed: 0");
        lblYears.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        // --- ADD ALL PANELS TO WINDOW ---
        add(topPanel, BorderLayout.NORTH); // Buttons at top
        add(scroll, BorderLayout.CENTER); // Results in middle
        add(lblYears, BorderLayout.SOUTH); // Years at bottom

        // --- BUTTON ACTIONS: What happens when clicked ---

        // LOAD BUTTON: When clicked, calculate and show results
        btnLoad.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadProductData();
            }
        });
          btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveProductData();
            }
        });
    }

    // 4. METHOD: LOAD PRODUCT DATA
    // This is called when Load button is clicked
    // It uses ProductSales class to get Total, Average, and counts Over/Under
    private void loadProductData() {
       
        int total = salesCalc.TotalSales(MatrtresProduct);
        double average = salesCalc.AverageSales(MatrtresProduct);

       
        int overLimit = 0;
        int underLimit = 0;

        // Loop through all sales
        for (int i = 0; i < MatrtresProduct.length; i++) {
            for (int j = 0; j < MatrtresProduct[i].length; j++) {
                // If sale is MORE than 500, it is over limit
                if (MatrtresProduct[i][j] > SALES_LIMIT) {
                    overLimit++;
                } else {
                    // Otherwise it is under limit (500 or less)
                    underLimit++;
                }
            }
        }

        // Build the text to show in the text area
        // Must match screenshot: Total 2200, Average 367, Over 2, Under 4
        String report = "Total Sales: " + total + "\n"
                      + "Commission : " + Commission(average) + "\n"
                      + "VAT: " + Vat + "\n"
                      + "Custorm name: " + CustormName;

        // Show the report in the text area
        txtResults.setText(report);

        // Update bottom label: Years Processed = number of rows = 2
        // productSales.length = 2 (YEAR 1 and YEAR 2)
        lblYears.setText("Years Processed: " + MattresSales.length);
    }

    // 5. METHOD: SAVE PRODUCT DATA
    // This is called when Save button is clicked
    // It saves the text from txtResults to a file chosen by the user
    private void saveProductData() {
        // If user hasn't clicked Load yet, there is nothing to save
        if (txtResults.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please Load Product Data first!");
            return;
        }

        // Open a File Chooser so user can pick where to save
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(this);

        // If user clicked Save in the chooser
        if (result == JFileChooser.APPROVE_OPTION) {
            try {
                // Create a FileWriter to write to the chosen file
                FileWriter writer = new FileWriter(fileChooser.getSelectedFile());
                // Write the report text + Years label
                writer.write(txtResults.getText() + "\n" + lblYears.getText());
                writer.close(); // Always close file

                JOptionPane.showMessageDialog(this, "Product Data Saved Successfully!");
            } catch (IOException ex) {
                // If something goes wrong saving, show error
                JOptionPane.showMessageDialog(this, "Error saving file: " + ex.getMessage());
            }
        }
    }
        
    public static void main(String[] args) {
       

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MattresSalesGUI().setVisible(true);
            }
        });
    
    }
}
}
