
package com.mycompany.mattressalesgui;

public class ProductCalculations implements IProductCalculations {
    
 private String CustormName;
 private String ProductName;
 private double VAT;
 private double Commission;
 private double Total;
 
 public ProductCalculations(String CustormName, String ProductName, double VAT, double Commission , double Total){
     
      this.CustormName= CustormName ;
      this.VAT= VAT ;
    this.Commission= Commission;
    this.Total= Total;
    this.ProductName= ProductName;
 }
  public String getCustormerName(){
        return  CustormName ;
  }
   public double getVAT(){
        return  VAT;
   }
    public double getCommission(){
        return  Commission;
   }
     public double getTotal(){
        return  Total;
   }
      public String getProductName(){
        return  ProductName;
   }




    // METHOD 1: TOTAL
    @Override
    public double Vat(double[][] productSales) {
        double totalVat = 15; // 
       
        for (int i = 0; i < productSales.length; i++) {
            // Loop quarters (columns)
            for (int j = 0; j < productSales[i].length; j++) {
                totalVat += productSales[i][j]; 
            }
        }
        return totalVat; 
    }

    // METHOD 2: Commision
    @Override
    public double Commission(int[][] productSales) {
        double total = Commission(productSales); // Reuse Method 1
        int count = 0; // How many values? 2 x 3 = 6
        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {
                count++;
            }
        }
        return (double) total / count; // 2200 / 6 = 366.66
    }

    // METHOD 3: Total
    @Override
    public double Total(int[][] productSales) {
        int max = productSales[0][0]; 
        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {
                if (productSales[i][j] > max) {
                    max = productSales[i][j]; 
                }
            }
        }
        return max; 
    }

    

    
}
